package com.ncu.assignment.validation;
public class StudentValidationMessage
{
	public static final String mme="Please donot let it be empty.\nRe-fill the form";
	public static final String dfe="Please enter correct date.\nRe-fill the form";
	public static final String se="Please enter minimum 1 Skill/Qualification.\nRe-fill the form";	
}
